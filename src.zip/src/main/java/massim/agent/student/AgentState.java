package massim.agent.student;

/** Agent state enumeration type. */
public enum AgentState {
	init, walking, scouting, idle, ready, waiting, finished, terminated
}
